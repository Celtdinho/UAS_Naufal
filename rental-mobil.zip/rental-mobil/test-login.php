<?php
require_once 'config/database.php';
require_once 'config/constants.php';

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME,
        DB_USER, 
        DB_PASS
    );
    
    echo "✅ Database connected!<br>";
    
    // Cek user admin
    $stmt = $pdo->query("SELECT * FROM users WHERE username = 'admin'");
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($admin) {
        echo "✅ Admin user found:<br>";
        echo "Username: " . $admin['username'] . "<br>";
        echo "Email: " . $admin['email'] . "<br>";
        echo "Role: " . $admin['role'] . "<br>";
        
        // Test password
        $test_password = 'admin123';
        if (password_verify($test_password, $admin['password'])) {
            echo "✅ Password 'admin123' is CORRECT!<br>";
        } else {
            echo "❌ Password 'admin123' is WRONG!<br>";
            echo "Hash in DB: " . $admin['password'] . "<br>";
        }
    } else {
        echo "❌ Admin user not found!<br>";
    }
    
} catch(PDOException $e) {
    echo "❌ Connection failed: " . $e->getMessage();
}
?>