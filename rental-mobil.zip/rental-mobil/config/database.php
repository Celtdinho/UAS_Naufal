<?php
// Database configuration for InfinityFree
define('DB_HOST', 'sql308.infinityfree.com');  // Ganti XXX dengan host Anda
define('DB_USER', 'if0_40846852');             // Ganti dengan username database
define('DB_PASS', 'cY7h3ZRVxjCnAz');  // Ganti dengan password database
define('DB_NAME', 'if0_40846852_rental_mobil'); // Ganti dengan nama database

// Timezone
date_default_timezone_set('Asia/Jakarta');

// Display errors (turn off in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>