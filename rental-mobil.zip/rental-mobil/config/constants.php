<?php
// Base URL untuk InfinityFree
// Ganti dengan domain Anda, contoh: https://namadomain.infinityfreeapp.com
// atau http://namadomain.epizy.com
define('BASEURL', 'rentalmobilnaufal.infinityfreeapp.com');

// Site Name
define('SITENAME', 'Rental Mobil');

// Upload path - SESUAIKAN DENGAN INFINITYFREE
define('UPLOAD_PATH', dirname(__DIR__) . '/public/uploads/');
define('UPLOAD_URL', BASEURL . '/public/uploads/');
?>